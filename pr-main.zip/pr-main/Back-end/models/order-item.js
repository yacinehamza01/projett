// Importation du module mongoose
const mongoose = require('mongoose');

// Définition du schéma pour les éléments de commande
const orderItemSchema = mongoose.Schema({
    // Définition du champ "quantity" avec un type Number et requis
    quantity: {
        type: Number,
        required: true
    },
    // Définition du champ "product" comme une référence à un produit dans une autre collection
    product: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product' // Le modèle de produit auquel il fait référence
    }
});

// Création et exportation du modèle OrderItem basé sur le schéma
exports.OrderItem = mongoose.model('OrderItem', orderItemSchema);
