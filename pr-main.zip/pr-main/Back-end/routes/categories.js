// Importation du modèle Category depuis le dossier ../models/category
const { Category } = require('../models/category');

// Importation du framework Express
const express = require('express');

// Création d'un routeur Express
const router = express.Router();

// Route pour récupérer la liste de toutes les catégories
router.get('/', async (req, res) => {
    // Récupération de la liste des catégories depuis la base de données
    const categoryList = await Category.find();

    // Vérification si la liste des catégories est vide
    if (!categoryList) {
        res.status(500).json({ success: false }); // Réponse d'erreur si la liste est vide
    }

    // Envoi de la liste des catégories
    res.send(categoryList);
});

// Route pour récupérer une catégorie par son ID
router.get("/:id", async (req, res) => {
    // Recherche de la catégorie par son ID dans la base de données
    const category = await Category.findById(req.params.id);

    // Vérification si la catégorie existe
    if (!category) {
        return res.status(200).json({ success: true, message: "La catégorie avec cet ID n'existe pas" });
    }

    // Envoi de la catégorie
    res.send(category);
});

// Route pour mettre à jour une catégorie par son ID
router.put("/:id", async (req, res) => {
    // Mise à jour de la catégorie dans la base de données
    const category = await Category.findByIdAndUpdate(
        req.params.id,
        {
            name: req.body.name,
            icon: req.body.icon,
            color: req.body.color
        },
        { new: true }
    );

    // Vérification si la catégorie a été mise à jour avec succès
    if (!category) {
        return res.status(400).send("La catégorie ne peut pas être mise à jour");
    }

    // Envoi de la catégorie mise à jour
    res.send(category);
});

// Route pour créer une nouvelle catégorie
router.post('/', async (req, res) => {
    // Création d'une nouvelle catégorie avec les données fournies dans la requête
    let category = new Category({
        name: req.body.name,
        icon: req.body.icon,
        color: req.body.color
    });

    // Enregistrement de la nouvelle catégorie dans la base de données
    category = await category.save();

    // Vérification si la catégorie a été créée avec succès
    if (!category) {
        res.status(400).send("La catégorie existe déjà");
    }

    // Envoi de la nouvelle catégorie créée
    res.send(category);
});

// Route pour supprimer une catégorie par son ID
router.delete("/:id", (req, res) => {
    // Recherche et suppression de la catégorie par son ID dans la base de données
    Category.findByIdAndDelete(req.params.id)
        .then(category => {
            // Vérification si la catégorie a été trouvée et supprimée avec succès
            if (category) {
                return res.status(200).json({ success: true, message: "La catégorie a été supprimée" });
            } else {
                return res.status(404).send({ success: false, message: "Catégorie non trouvée" });
            }
        })
        .catch(err => {
            return res.status(400).json({ success: false, error: err });
        });
});

// Exportation du routeur
module.exports = router;
