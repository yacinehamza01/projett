// Importation du modèle Category depuis le dossier ../models/category
const { Category } = require('../models/category');

// Importation du modèle Product depuis le dossier ../models/product
const { Product } = require('../models/product');

// Importation du framework Express
const express = require('express');

// Création d'un routeur Express
const router = express.Router();

// Importation du module mongoose
const mongoose = require('mongoose');

// Importation de multer pour la gestion des fichiers
const multer = require("multer");

// Mapping des types de fichiers acceptés avec leurs extensions correspondantes
const FILE_TYPE_MAP = {
    'image/png': 'png',
    'image/jpeg': 'jpeg',
    'image/jpg': 'jpg'
}

// Configuration du stockage des fichiers avec multer
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const isValid = FILE_TYPE_MAP[file.mimetype];
        let uploadError = new Error('invalid image type');

        if(isValid) {
            uploadError = null
        }
      cb(uploadError, 'public/uploads')
    },
    filename: function (req, file, cb) {
        
      const fileName = file.originalname.split(' ').join('-');
      const extension = FILE_TYPE_MAP[file.mimetype];
      cb(null, `${fileName}-${Date.now()}.${extension}`)
    }
});

// Configuration des options d'upload pour multer
const uploadOptions = multer({ storage: storage });

// Route pour récupérer la liste de produits avec la possibilité de filtrer par catégorie
router.get('/', async (req, res) => {
    let filter = {};
    if (req.query.category) {
        filter = { category: req.query.category.split(',') };
    }

    // Récupération de la liste des produits depuis la base de données, en populant la référence à la catégorie
    const productList = await Product.find(filter).populate("category");

    // Vérification si la liste des produits est vide
    if (!productList) {
        res.status(500).json({ success: false });
    }

    // Envoi de la liste des produits
    res.send(productList);
});

// Route pour récupérer un produit par son ID
router.get("/:id", async (req, res) => {
    // Recherche du produit par son ID dans la base de données, en populant la référence à la catégorie
    const product = await Product.findById(req.params.id).populate("category");

    // Vérification si le produit existe
    if (!product) {
        res.status(500).send({ success: false });
    }

    // Envoi du produit
    res.send(product);
});

// Route pour récupérer le nombre total de produits
router.get("/get/count", async (req, res) => {
    // Comptage du nombre total de produits dans la base de données
    const productCount = await Product.countDocuments();

    // Vérification si le comptage des produits a réussi
    if (!productCount) {
        res.status(500).send({ success: false });
    }

    // Envoi du nombre total de produits
    res.send({ productCount: productCount });
});

// Route pour récupérer les produits vedettes avec un nombre spécifié
router.get("/get/featured/:count", async (req, res) => {
    const count = req.params.count ? req.params.count : 0;

    // Récupération des produits vedettes depuis la base de données avec le nombre spécifié
    const featuredProducts = await Product.find({ isFeatured: true }).limit(+count);

    // Vérification si les produits vedettes ont été récupérés avec succès
    if (!featuredProducts) {
        res.status(500).send({ success: false });
    }

    // Envoi des produits vedettes
    res.send(featuredProducts);
});

// Route pour créer un nouveau produit
router.post(`/`, uploadOptions.single('image'), async (req, res) =>{
    const category = await Category.findById(req.body.category);
    if(!category) return res.status(400).send('Invalid Category')

    const file = req.file;
    if(!file) return res.status(400).send('No image in the request')

    const fileName = file.filename
    const basePath = `${req.protocol}://${req.get('host')}/public/uploads/`;
    let product = new Product({
        name: req.body.name,
        description: req.body.description,
        richDescription: req.body.richDescription,
        image: `${basePath}${fileName}`,// "http://localhost:3000/public/upload/image-2323232"
        brand: req.body.brand,
        price: req.body.price,
        category: req.body.category,
        countInStock: req.body.countInStock,
        rating: req.body.rating,
        numReviews: req.body.numReviews,
        isFeatured: req.body.isFeatured,
    })

    product = await product.save();

    if(!product) 
    return res.status(500).send('The product cannot be created')

    res.send(product);
})

// Route pour mettre à jour un produit par son ID
router.put("/:id", async (req, res) => {
    if (!mongoose.isValidObjectId(req.params.id)) {
        return res.status(400).send("ID de produit invalide");
    }

    // Recherche de la catégorie du produit par son ID
    const category = await Category.findById(req.body.category);
    if (!category) {
        return res.status(400).send("La catégorie n'existe pas");
    }

    // Mise à jour du produit dans la base de données
    const product = await Product.findByIdAndUpdate(req.params.id,
        {
            name: req.body.name,
            image: req.body.image,
            countInStock: req.body.countInStock,
            description: req.body.description,
            richDescription: req.body.richDescription,
            brand: req.body.brand,
            price: req.body.price,
            category: req.body.category,
            rating: req.body.rating,
            numReview: req.body.numReview,
            isFeatured: req.body.isFeatured
        },
        { new: true }
    );

    // Vérification si le produit a été mis à jour avec succès
    if (!product) {
        return res.status(400).send("Le produit ne peut pas être mis à jour");
    }

    // Envoi du produit mis à jour
    res.send(product);
});

// Route pour supprimer un produit par son ID
router.delete("/:id", (req, res) => {
    // Recherche et suppression du produit par son ID dans la base de données
    Product.findByIdAndDelete(req.params.id)
        .then(product => {
            // Vérification si le produit a été trouvé et supprimé avec succès
            if (product) {
                return res.status(200).json({ success: true, message: "Le produit a été supprimé" });
            } else {
                return res.status(404).send({ success: false, message: "Produit non trouvé" });
            }
        })
        .catch(err => {
            return res.status(400).json({ success: false, error: err });
        });
});

// Route pour mettre à jour les images d'une galerie de produits par ID
router.put(
    '/gallery-images/:id', 
    uploadOptions.array('images', 10), 
    async (req, res)=> {
        if(!mongoose.isValidObjectId(req.params.id)) {
            return res.status(400).send('Invalid Product Id')
         }
         const files = req.files
         let imagesPaths = [];
         const basePath = `${req.protocol}://${req.get('host')}/public/uploads/`;

         if(files) {
            files.map(file =>{
                imagesPaths.push(`${basePath}${file.filename}`);
            })
         }

         const product = await Product.findByIdAndUpdate(
            req.params.id,
            {
                images: imagesPaths
            },
            { new: true}
        )

        if(!product)
            return res.status(500).send('the gallery cannot be updated!')

        res.send(product);
    }
)

// Exportation du routeur
module.exports = router;
