// Importation du modèle Order depuis le dossier ../models/order
const { Order } = require('../models/order');

// Importation du framework Express
const express = require('express');

// Importation du modèle OrderItem depuis le dossier ../models/order-item
const { OrderItem } = require('../models/order-item');

// Création d'un routeur Express
const router = express.Router();

// Route pour récupérer la liste des commandes avec les noms d'utilisateurs associés, triées par date de commande décroissante
router.get(`/`, async (req, res) =>{
    const orderList = await Order.find().populate('user', 'name').sort({'dateOrdered': -1});

    // Vérification si la liste des commandes est vide
    if(!orderList) {
        res.status(500).json({success: false});
    } 

    // Envoi de la liste des commandes
    res.send(orderList);
});

// Route pour récupérer une commande par son ID avec les détails des articles de commande et des produits associés
router.get(`/:id`, async (req, res) =>{
    const order = await Order.findById(req.params.id)
        .populate('user', 'name')
        .populate({ 
            path: 'orderItems', 
            populate: {
                path: 'product', 
                populate: 'category'
            } 
        });

    // Vérification si la commande existe
    if(!order) {
        res.status(500).json({success: false});
    } 

    // Envoi des détails de la commande
    res.send(order);
});

// Route pour créer une nouvelle commande avec les articles de commande
router.post('/', async (req,res)=>{
    // Création des identifiants des articles de commande à partir des données fournies
    const orderItemsIds = Promise.all(req.body.orderItems.map(async (orderItem) =>{
        let newOrderItem = new OrderItem({
            quantity: orderItem.quantity,
            product: orderItem.product
        });

        newOrderItem = await newOrderItem.save();

        return newOrderItem._id;
    }));
    const orderItemsIdsResolved =  await orderItemsIds;

    // Calcul du prix total de la commande en utilisant les prix des produits
    const totalPrices = await Promise.all(orderItemsIdsResolved.map(async (orderItemId)=>{
        const orderItem = await OrderItem.findById(orderItemId).populate('product', 'price');
        const totalPrice = orderItem.product.price * orderItem.quantity;
        return totalPrice;
    }));
    const totalPrice = totalPrices.reduce((a,b) => a + b , 0);

    // Création de la commande avec les données fournies
    let order = new Order({
        orderItems: orderItemsIdsResolved,
        shippingAddress1: req.body.shippingAddress1,
        shippingAddress2: req.body.shippingAddress2,
        city: req.body.city,
        zip: req.body.zip,
        country: req.body.country,
        phone: req.body.phone,
        status: req.body.status,
        totalPrice: totalPrice,
        user: req.body.user,
    });
    order = await order.save();

    // Vérification si la commande a été créée avec succès
    if(!order) {
        return res.status(400).send('La commande ne peut pas être créée!');
    }

    // Envoi des détails de la commande créée
    res.send(order);
});

// Route pour mettre à jour le statut d'une commande par son ID
router.put('/:id', async (req, res)=> {
    const order = await Order.findByIdAndUpdate(
        req.params.id,
        { status: req.body.status },
        { new: true }
    );

    // Vérification si la commande a été mise à jour avec succès
    if(!order) {
        return res.status(400).send('La commande ne peut pas être mise à jour!');
    }

    // Envoi des détails de la commande mise à jour
    res.send(order);
});

// Route pour supprimer une commande par son ID, avec suppression des articles de commande associés
router.delete('/:id', (req, res)=>{
    Order.findByIdAndRemove(req.params.id).then(async order =>{
        if(order) {
            await order.orderItems.map(async orderItem => {
                await OrderItem.findByIdAndRemove(orderItem);
            });
            return res.status(200).json({ success: true, message: 'La commande a été supprimée!' });
        } else {
            return res.status(404).json({ success: false , message: "Commande non trouvée!" });
        }
    }).catch(err=>{
        return res.status(500).json({ success: false, error: err });
    });
});

// Route pour récupérer le total des ventes de toutes les commandes
router.get('/get/totalsales', async (req, res)=> {
    // Calcul du total des ventes en agrégeant les prix totaux de toutes les commandes
    const totalSales = await Order.aggregate([
        { $group: { _id: null , totalsales : { $sum : '$totalPrice'}}}
    ]);

    // Vérification si le calcul du total des ventes a réussi
    if(!totalSales) {
        return res.status(400).send('Les ventes de commandes ne peuvent pas être générées');
    }

    // Envoi du total des ventes
    res.send({ totalsales: totalSales.pop().totalsales });
});

// Route pour récupérer le nombre total de commandes
router.get(`/get/count`, async (req, res) =>{
    // Comptage du nombre total de commandes dans la base de données
    const orderCount = await Order.countDocuments();

    // Vérification si le comptage des commandes a réussi
    if(!orderCount) {
        res.status(500).json({ success: false });
    } 

    // Envoi du nombre total de commandes
    res.send({ orderCount: orderCount });
});

// Route pour récupérer les commandes d'un utilisateur par son ID, avec les détails des articles de commande et des produits associés
router.get(`/get/userorders/:userid`, async (req, res) =>{
    const userOrderList = await Order.find({ user: req.params.userid })
        .populate({ 
            path: 'orderItems', 
            populate: {
                path: 'product', 
                populate: 'category'
            } 
        })
        .sort({'dateOrdered': -1});

    // Vérification si la liste des commandes de l'utilisateur a été récupérée avec succès
    if(!userOrderList) {
        res.status(500).json({ success: false });
    } 

    // Envoi de la liste des commandes de l'utilisateur
    res.send(userOrderList);
});

// Exportation du routeur
module.exports = router;
